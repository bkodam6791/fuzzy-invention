"use strict";
var $ = function(id) { return document.getElementById(id); };

function convertTemp()
{
    var entered = $("degrees_entered").value;
    entered = parseFloat(entered);
    if
        (!isNaN(entered))
            {
                var result;
                if($("to_celsius").checked)
                    {
                        result = (entered-32) * 5/9;
                    }
                else if($("to_fahrenheit").checked)
                    {
                        result = (9/5 * entered) + 32;
                    }
                $("degrees_computed").value = result.toFixed(0);
            }
    else
        {
            alert("You must enter a valid number for degrees.");
        }
    $("degrees_entered").focus();
}
function toCelsius()
{
        $("degrees_label_1").firstChild.nodeValue = "Enter C degrees:";
        $("degrees_label_2").firstChild.nodeValue = "Degrees Celsius";
    clearTextBoxes();
}
function toFahrenheit()
{
        $("degrees_label_1").firstChild.nodeValue = "Enter F degrees:";
        $("degrees_label_2").firstChild.nodeValue = "Degrees Fahrenheit";
    clearTextBoxes();
}

var clearTextBoxes = function() {
    $("degrees_entered").value = "";
    $("degrees_computed").value = "";
};

window.onload = function() {
    $("convert").onclick = convertTemp;
    $("to_celsius").onclick = toCelsius;
    $("to_fahrenheit").onclick = toFahrenheit;
	$("degrees_entered").focus();
};
