var $ = function(id) {
    return document.getElementById(id);
};
var makeChange = function(amount) {
  var quarter = amount / 25;
  amount = amount % 25;
  var dime = amount / 10;
  amount = amount % 10;
  var nickel = amount / 5;
  var penny = amount % 5;
        
  $("quarters").value = parseInt(quarter);
  $("dimes").value = parseInt(dime);
  $("nickels").value = parseInt(nickel);
  $("pennies").value = parseInt(penny);
        
};
var processEntry = function() {
    var amount = parseInt($("cents").value);
    if (isNaN(amount) || isNaN(amount)){
        alert("Both entries must be numeric");
    }
    else if(amount >= 99 || amount <= 0 ){
        alert("The value of amount must be between 0 and 99");
    }
    else{
       makeChange(amount);
    }
};
window.onload = function(){
   $("cents").focus();
   $("calculate").onclick = processEntry;
};