"use strict";
var $ = function (id) {
    return document.getElementById(id); 
};
var calculateTax = function(subTotal, taxRate) {
    var tax = (subTotal * taxRate)/100;
    tax = parseFloat(tax.toFixed(2));
    return tax;
};
var processEntries = function() {
    var subTotal = parseFloat($("subtotal").value);
    var rate = parseFloat($("tax_rate").value);
    if (isNaN(subTotal) || isNaN(rate)){
        alert("Both entries must be numeric");
    }
    else if(subTotal >= 10000 || subTotal <= 0 ){
        alert("The value of Subtotal must be between 0 and 10000");
    }
    else if(rate >= 12 || rate <= 0){
        alert("The value of Rate must be between 0 and 12");}
    else{
        var salesTax = calculateTax( subTotal, rate );
        //alert(salesTax);
        $("sales_tax").value = salesTax;
        var totalValue = salesTax + subTotal;
        $("total").value = totalValue;
    }
        
};

var clearEntries = function(){
    $("subtotal").value = "";
    $("tax_rate").value = "";
    $("sales_tax").value = "";
    $("total").value = "";
}

window.onload = function(){
    $("calculate").onclick = processEntries;
    $("clear").onclick = clearEntries;
    $("subtotal").focus();
};